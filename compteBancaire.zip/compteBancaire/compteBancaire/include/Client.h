#include<string>
#include"Compte.h"

#ifndef CLIENT_H
#define CLIENT_H

using namespace std;

class Client
{
   public:
        Client();
        Client(string n, string a);
        bool ajoutCompte(Compte c);
        int soldeCumule();
        int nbreCe();
        int nbreCc();


    private:
        string nom;
        string adresse;
        Compte* tabCompte;
        int libre;
};

#endif // CLIENT_H
