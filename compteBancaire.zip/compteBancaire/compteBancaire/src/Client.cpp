
#include "Client.h"

using namespace std;


Client::Client(){           //constructeur sans argument de l'objet client client

    tabCompte=new Compte[libre];
    libre=0;
}

Client::Client(string n, string a){     //constructeur avec argument de l'objet client

    nom=n;
    adresse=a;
    tabCompte= new Compte[libre];
    libre=0;
}

bool Client::ajoutCompte(Compte c){

    if(libre>=25)
        return false;
    else{

        tabCompte[libre]=c;
        libre++;
        return true;
    }
}

int Client::soldeCumule(){

    int x=0;

    for(int i=0;i<libre;i++){

        x=x+this->tabCompte[i].getSolde();
    }

    return x;

}

