#include <iostream>
#include"Compte.h"
#include"CompteCheque.h"
#include"COmpteEpargne.h"
#include"Client.h"

using namespace std;

int main()
{
    Client client1;
    COmpteEpargne compteE;
    CompteCheque compteC;

    compteC.crediter(1000);
    compteE.crediter(1000);

    client1.ajoutCompte(compteC);
    client1.ajoutCompte(compteE);

   cout<<client1.soldeCumule()<<endl;

    compteC.debiter(500);
    cout<<compteC.getSolde()<<endl;

   cout<<client1.soldeCumule()<<endl;


    return 0;
}
